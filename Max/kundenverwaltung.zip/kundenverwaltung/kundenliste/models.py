from django.db import models


class Kunde(models.Model):
    Kundennummer = models.IntegerField(default='-1')
    Vorname = models.CharField(max_length=200, default='Max')
    Nachname = models.CharField(max_length=200, default='Felker')

class Kurs(models.Model):
    Name = models.CharField(max_length=500, default="Body pumping")
    Kuerzel = models.CharField(max_length=50, default="BP")
    Trainer = models.CharField(max_length=50, default = "MF")

class Kunde_Kurs(models.Model):
    Kundennummer = models.IntegerField(default=-1)
    KursKuerzel = models.CharField(max_length=50, default="BP")