from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("alle-kunden/<str:kurskuerzel>/", views.kunden_anzeigen, name="alle-kunden-fuer-kurs" ),
    path("alle-kunden/", views.kunden_anzeigen, name="alle-kunden"),
    path("kurs-buchen/", views.kurs_buchen, name="kurs-buchen")
]