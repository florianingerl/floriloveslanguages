from kundenliste.models import Kunde,Kurs

k1 = Kunde(Vorname="Florian",Nachname="Hitler")
k1.save()

k2= Kunde(Vorname="Max",Nachname="Felker")
k2.save()

k3= Kunde(Vorname="David",Nachname="Obermann")
k3.save()

kurs1 = Kurs(Name="Wordpress", Kuerzel="WP")
kurs1.save()

kurs2 = Kurs(Name="Yoga", Kuerzel="Y")
kurs2.save()

kurs3 = Kurs(Name="Java Programmierung", Kuerzel="JP")
kurs3.save()