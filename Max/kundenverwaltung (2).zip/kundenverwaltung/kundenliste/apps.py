from django.apps import AppConfig


class KundenlisteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kundenliste'
