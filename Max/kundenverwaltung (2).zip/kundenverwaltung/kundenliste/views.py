from django.http import HttpResponse
from django.template import loader

from .models import Kunde,Kurs,Kunde_Kurs



def index(request):
    template = loader.get_template("index.html")
    return HttpResponse(template.render({}, request))

def kunden_anlegen(request):

    template = loader.get_template("kunden_anlegen.html")

    if request.method == 'GET':
        return HttpResponse(template.render({}, request))
    elif request.method == 'POST':
        k = Kunde(Vorname = request.POST.get("vorname"),Nachname=request.POST.get("nachname") )
        k.save()
        context = {
             'kunde': k
        }
        return HttpResponse(template.render(context, request))



def kunden_anzeigen(request, kurskuerzel = None):
    kurs = None
    if kurskuerzel:
        kurs = Kurs.objects.get(Kuerzel = kurskuerzel)
    kunden = Kunde.objects.all()
    if kurs:
        kunde_kursen = Kunde_Kurs.objects.filter(KursKuerzel = kurskuerzel)
        kunden = []
        for kunde_kurs in kunde_kursen:
            kunden.append( Kunde.objects.get(Kundennummer = kunde_kurs.Kundennummer ) )

    template = loader.get_template("alle_kunden.html")
    context = {
        "kunden": kunden,
        "kurs" : kurs
    }
    return HttpResponse(template.render(context, request))

def kurs_buchen(request):
    print("The kurs_buchen endpoint is called")
    template = loader.get_template("kurs_buchen.html")

    if request.method == 'GET':
        kurse = Kurs.objects.all()
        context = {
            "kurse": kurse
        }
        return HttpResponse(template.render(context, request))
    elif request.method == 'POST':
        print("This is executed!")
        kundennummer = request.POST.get("kundennummer")
        kurskuerzel = request.POST.get("kurs")
        kunde = Kunde.objects.get(Kundennummer = kundennummer)
        kurs = Kurs.objects.get(Kuerzel = kurskuerzel)
        kk = Kunde_Kurs(Kundennummer = kunde, KursKuerzel = kurs)
        kk.save()

        context = {
            'kurs_gebucht': kurs,
            'kunde': kunde
        }
        return HttpResponse(template.render(context, request) )

