from django.db import models


class Kunde(models.Model):
    Kundennummer = models.AutoField(primary_key=True)
    Vorname = models.CharField(max_length=200, default='Max')
    Nachname = models.CharField(max_length=200, default='Felker')
    Geburtsdatum = models.CharField(max_length=200, default='3.3.1993')

    def __str__(self):
        return f'{self.Vorname} {self.Nachname} ({self.Kundennummer}, {self.Geburtsdatum} )'
    

class Kurs(models.Model):
    Name = models.CharField(max_length=500, default="Body pumping")
    Kuerzel = models.CharField(max_length=50,primary_key=True)
    Trainer = models.CharField(max_length=50, default = "MF")
    Datum = models.CharField(max_length=50, default='3.3.1993')

    def __str__(self):
        return f'{self.Name} ({self.Kuerzel}, {self.Datum})'

class Kunde_Kurs(models.Model):
    Kundennummer = models.ForeignKey(Kunde, on_delete=models.CASCADE)
    KursKuerzel = models.ForeignKey(Kurs, on_delete=models.CASCADE) 